#include <Wire.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Cexp.h>
#include <Servo.h>

#define S0 2
#define S1 3
#define S2 4
#define S3 5
#define sensorOut 6

#define IR_read digitalRead(7)

hd44780_I2Cexp lcd;
Servo myServo;

int redValue, blueValue;
int score = 0;

// 🔴 Read Red
int readRed() {
  digitalWrite(S2, LOW);
  digitalWrite(S3, LOW);
  return pulseIn(sensorOut, LOW);
}

// 🔵 Read Blue
int readBlue() {
  digitalWrite(S2, LOW);
  digitalWrite(S3, HIGH);
  return pulseIn(sensorOut, LOW);
}

void setup() {

  pinMode(S0, OUTPUT);
  pinMode(S1, OUTPUT);
  pinMode(S2, OUTPUT);
  pinMode(S3, OUTPUT);
  pinMode(sensorOut, INPUT);

  digitalWrite(S0, HIGH);
  digitalWrite(S1, LOW);

  myServo.attach(9);
  delay(500);
  myServo.write(0);
  delay(500);
  myServo.write(70);
  delay(500);
  myServo.write(130);
  delay(500);
  Serial.begin(9600);

  // ✅ LCD setup
  lcd.begin(16, 2);
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Score: 0");
}

void loop() {
  unsigned long startTime = millis();
  if (IR_read == 0) {


    Serial.println("HAVE BALL ");
    lcd.setCursor(1, 5);
    lcd.print("BALL");
    delay(250);
    while (millis() - startTime < 50000) {  // 20 seconds
      //startTime = millis();


      redValue = readRed();
      delay(80);
      blueValue = readBlue();

      Serial.print("Red: ");
      Serial.print(redValue);
      Serial.print("  Blue: ");
      Serial.println(blueValue);

      //int moveTime = 450;
      if (blueValue < redValue - 20) {


        lcd.setCursor(1, 5);
        lcd.print("BLUE");

        Serial.println("  Blue: ");
        myServo.write(0);



        delay(2000);
        // 🔥 BLUE = +2
        score += 2;

        lcd.setCursor(0, 0);
        lcd.print("Score: ");
        lcd.print(score);
        lcd.print("   ");
        break;
      }

      // 🔵 BLUE → move LEFT then return
      else
        // 🔴 RED → move RIGHT then return
        if (redValue < blueValue - 20) {


          Serial.println("  RED: ");
          lcd.setCursor(1, 5);
          lcd.print("RED ");
          myServo.write(160);

          delay(2000);

          // 🔥 RED = +1
          score += 1;

          lcd.setCursor(0, 0);
          lcd.print("Score: ");
          lcd.print(score);
          lcd.print("   ");
          break;
        }
      myServo.write(70);
    }
  }
  myServo.write(70);
  lcd.setCursor(1, 5);
  lcd.print("    ");
  //delay(500);
}