#include <Wire.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Cexp.h>
#include <Servo.h>



#define IR_read digitalRead(7)
#define SORT_READ digitalRead(5)

hd44780_I2Cexp lcd;
Servo myServo;

int redValue, blueValue;
int score = 0;


void setup() {

  pinMode(7, INPUT);
  pinMode(5, INPUT);


  myServo.attach(9);
  delay(500);
  myServo.write(0);
  delay(500);
  myServo.write(70);
  delay(500);
  myServo.write(130);
  delay(500);
  Serial.begin(9600);

  // ✅ LCD setup
  lcd.begin(16, 2);
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Score: 0");
}

void loop() {
  unsigned long startTime = millis();
  if (IR_read == 0) {

    Serial.println("HAVE BALL ");
    lcd.setCursor(1, 5);
    lcd.print("BALL");
    delay(1000);
    while (millis() - startTime < 50000) {  // 20 seconds
      //startTime = millis();
 
      Serial.print("redValue: ");
      Serial.println(redValue);

      //int moveTime = 450;
      if (SORT_READ == 1) {
        lcd.setCursor(1, 5);
        lcd.print("BLACK");

        Serial.println("  BLACK: ");
        myServo.write(0);
        delay(2000);
        // 🔥 BLUE = +2
        score += 2;

        lcd.setCursor(0, 0);
        lcd.print("Score: ");
        lcd.print(score);
        lcd.print("   ");
        break;
      } else if (SORT_READ == 0) {
        Serial.println("  White: ");
        lcd.setCursor(1, 5);
        lcd.print("White ");
        myServo.write(160);

        delay(2000);
        score += 1;

        lcd.setCursor(0, 0);
        lcd.print("Score: ");
        lcd.print(score);
        lcd.print("   ");
        break;
      }
      myServo.write(70);
    }
  }
  myServo.write(70);
  lcd.setCursor(1, 5);
  lcd.print("    ");
  //delay(500);
}