#include <Servo.h>
#define IN1 9
#define IN2 8
#define ENA 10
#define SERVO_PIN 6
#define TRIGGER_PIN 12
#define BUTTON_PIN 4
#define DONE_PIN 11
Servo liftServo;
int pressCount = 0;
bool lastButtonState = HIGH;
void setup() {
  delay(2000);
  Serial.begin(9600);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  //  pinMode(ENA, OUTPUT);
  pinMode(TRIGGER_PIN, OUTPUT);

  digitalWrite(TRIGGER_PIN, HIGH);
  liftServo.attach(SERVO_PIN);


  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  liftServo.write(10);
  delay(1000);
  M_STOP();

  liftServo.write(10);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(DONE_PIN, INPUT_PULLUP);
  lastButtonState = digitalRead(BUTTON_PIN);
  Serial.println("Press button to start lifting and shooting");
}
void loop() {
  checkButton();
  if (pressCount == 1) {
    liftServo.write(10);
    delay(1500);
    liftServo.write(130);
    delay(1500);
    delay(5000);
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    delay(4000);
    M_STOP();
    liftServo.write(10);
    Serial.println("Lifting and shooting done. Press button to start sorting");
    pressCount = 0;

    digitalWrite(TRIGGER_PIN, HIGH);
    delay(2500);
    digitalWrite(TRIGGER_PIN, 0);
  } /*
  if (pressCount == 3) {
    digitalWrite(TRIGGER_PIN, LOW);
    delay(500);
    digitalWrite(TRIGGER_PIN, HIGH);
    Serial.println("Waiting for Arduino 2 to finish sorting");
    while (digitalRead(DONE_PIN) == HIGH) {
      delay(100);
    }
    Serial.println("Sorting done. Press button to reset");
    pressCount = 4;
  }
  if (pressCount == 5) {
    analogWrite(ENA, 0);
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
    liftServo.write(10);
    digitalWrite(TRIGGER_PIN, HIGH);
    pressCount = 0;
    Serial.println("Reset. Press button to start again");
  }*/
}
void checkButton() {
  bool currentButtonState = digitalRead(BUTTON_PIN);
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    delay(50);
    if (digitalRead(BUTTON_PIN) == LOW) {
      pressCount++;
      Serial.print("Button pressed. Count: ");
      Serial.println(pressCount);
    }
  }
  lastButtonState = currentButtonState;
}



void M_STOP() {
  digitalWrite(IN1, 0);
  digitalWrite(IN2, LOW);
}